import os
import logging
from typing import Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from livekit.api import AccessToken, VideoGrants, LiveKitAPI, CreateAgentDispatchRequest
import uvicorn
from dotenv import load_dotenv

# Load environment configuration
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("drishti-token-server")

app = FastAPI(
    title="Drishti LiveKit Token Server",
    description="Authentication and token generation service for Drishti Mobile Voice Companion",
    version="1.0.0"
)

# Enable CORS for mobile and web clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


from pathlib import Path
from fastapi.responses import PlainTextResponse

@app.get("/health")
def health_check():
    """Health check endpoint to verify server is active and configured."""
    api_key_configured = bool(os.getenv("LIVEKIT_API_KEY"))
    api_secret_configured = bool(os.getenv("LIVEKIT_API_SECRET"))
    return {
        "status": "healthy",
        "livekit_configured": api_key_configured and api_secret_configured
    }


@app.get("/conversation-logs")
def get_conversation_logs(
    lines: int = Query(50, description="Number of recent log lines to retrieve"),
    raw: bool = Query(False, description="Return raw plain text")
):
    """Retrieve recent LLM conversation observation logs."""
    log_file = Path("/app/logs/llm_conversation.log")
    if not log_file.exists():
        log_file = Path(__file__).resolve().parent.parent / "agent" / "logs" / "llm_conversation.log"
    if not log_file.exists():
        return {"status": "no_logs_yet", "message": "No conversation turns recorded yet."}
    try:
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            all_lines = f.readlines()
        tail = "".join(all_lines[-lines:])
        if raw:
            return PlainTextResponse(tail)
        return {"status": "ok", "lines": len(tail.splitlines()), "logs": tail}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/token")
async def get_token(
    room: str = Query(..., description="Target LiveKit room name"),
    user: str = Query(..., description="Unique participant identity or user name")
):
    """
    Issues a signed JWT token granting audio, video, and data publishing permissions
    for the specified user in the requested room, and ensures an agent worker is dispatched.
    """
    api_key = os.getenv("LIVEKIT_API_KEY")
    api_secret = os.getenv("LIVEKIT_API_SECRET")
    livekit_url = os.getenv("LIVEKIT_URL")

    if not api_key or not api_secret:
        logger.error("Token request rejected: LIVEKIT_API_KEY or LIVEKIT_API_SECRET missing in environment")
        raise HTTPException(
            status_code=500,
            detail="Server misconfiguration: LIVEKIT_API_KEY or LIVEKIT_API_SECRET not set."
        )

    try:
        grants = VideoGrants(
            room_join=True,
            room=room,
            can_publish=True,
            can_subscribe=True,
            can_publish_data=True
        )

        token = AccessToken(api_key, api_secret)
        token.with_identity(user)
        token.with_grants(grants)
        jwt_token = token.to_jwt()

        logger.info(f"Generated LiveKit token for user '{user}' in room '{room}'")

        # Auto-dispatch agent to the room asynchronously without blocking token response
        if livekit_url:
            async def dispatch_background():
                try:
                    lk_api = LiveKitAPI(livekit_url, api_key, api_secret)
                    has_active_agent = False
                    try:
                        dispatches = await lk_api.agent_dispatch.list_dispatch(room)
                        for d in dispatches:
                            if d.agent_name in ["drishti-agent", ""]:
                                if not d.state.jobs:
                                    has_active_agent = True
                                    break
                                for job in d.state.jobs:
                                    if job.state.status in [0, 1]:
                                        has_active_agent = True
                                        break
                    except Exception:
                        has_active_agent = False

                    if not has_active_agent:
                        await lk_api.agent_dispatch.create_dispatch(
                            CreateAgentDispatchRequest(room=room, agent_name="")
                        )
                        logger.info(f"Dispatched default agent to room '{room}'")
                    await lk_api.aclose()
                except Exception as dispatch_err:
                    logger.debug(f"Agent auto-dispatch note: {dispatch_err}")

            import asyncio
            asyncio.create_task(dispatch_background())

        return {
            "token": jwt_token,
            "room": room,
            "identity": user,
            "ws_url": livekit_url
        }
    except Exception as exc:
        logger.exception("Failed to generate token")
        raise HTTPException(status_code=500, detail=f"Token creation failed: {str(exc)}")


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    reload_mode = os.getenv("RELOAD", "false").lower() == "true"
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=reload_mode)
