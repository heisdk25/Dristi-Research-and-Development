package ai.drishti.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * CameraX wrapper for on-device phone camera capture.
 * Provides high-speed frames for TFLite inference and fallback video feed.
 */
class PhoneCamera(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val onFrameAvailable: (Bitmap) -> Unit
) {

    private val tag = "PhoneCamera"
    private var cameraExecutor: ExecutorService? = null
    private var cameraProvider: ProcessCameraProvider? = null

    var isRunning: Boolean = false
        private set

    var lensFacing: Int = CameraSelector.LENS_FACING_BACK
        private set

    fun switchLens(newLens: Int) {
        if (lensFacing != newLens) {
            lensFacing = newLens
            Log.i(tag, "Switching PhoneCamera lens to: ${if (newLens == CameraSelector.LENS_FACING_FRONT) "FRONT" else "BACK"}")
            if (isRunning) {
                bindCameraUseCases()
            }
        }
    }

    fun start() {
        if (isRunning) return

        if (cameraExecutor == null || cameraExecutor?.isShutdown == true) {
            cameraExecutor = Executors.newSingleThreadExecutor()
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                bindCameraUseCases()
                isRunning = true
                Log.i(tag, "Phone CameraX started successfully.")
            } catch (e: Exception) {
                Log.e(tag, "Failed to initialize CameraX provider", e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun bindCameraUseCases() {
        val provider = cameraProvider ?: return
        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(lensFacing)
            .build()

        val imageAnalysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()

        val executor = cameraExecutor ?: Executors.newSingleThreadExecutor().also { cameraExecutor = it }

        imageAnalysis.setAnalyzer(executor) { imageProxy ->
            try {
                val bitmap = imageProxyToBitmap(imageProxy)
                if (bitmap != null) {
                    onFrameAvailable(bitmap)
                }
            } catch (e: Exception) {
                Log.e(tag, "Error processing camera frame", e)
            } finally {
                imageProxy.close()
            }
        }

        try {
            provider.unbindAll()
            provider.bindToLifecycle(lifecycleOwner, cameraSelector, imageAnalysis)
        } catch (e: Exception) {
            Log.e(tag, "Use case binding failed for lens $lensFacing", e)
        }
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
        val bitmap = try {
            image.toBitmap()
        } catch (e: Exception) {
            Log.e(tag, "Failed to convert ImageProxy to Bitmap using toBitmap()", e)
            null
        } ?: return null

        // Rotate bitmap according to sensor orientation & lens
        val rotation = image.imageInfo.rotationDegrees
        val matrix = Matrix()
        if (rotation != 0) {
            matrix.postRotate(rotation.toFloat())
        }
        if (lensFacing == CameraSelector.LENS_FACING_FRONT) {
            matrix.postScale(-1f, 1f) // Mirror front camera preview for natural display
        }

        val transformed = if (!matrix.isIdentity) {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap
        }
        transformed.setHasAlpha(false)
        return transformed
    }

    fun stop() {
        try {
            cameraProvider?.unbindAll()
            cameraProvider = null
            cameraExecutor?.shutdown()
            cameraExecutor = null
            isRunning = false
            Log.i(tag, "Phone CameraX stopped.")
        } catch (e: Exception) {
            Log.e(tag, "Error stopping CameraX", e)
        }
    }
}
